Date estimation 4. Raw Maximum Clade Credibility trees from BEAST inferences. 

Summary:
	summary.xlsx: A summary of tree heights and substitution rates of all subsamples using archeological dating of Ragna.

Models :
Paratyphi C strains only (strict clock rate) :
	ASM dating of Ragna to 1073 :
		subsample 1:
			ParatyphiC_01_1073.sc_con.tre
		subsample 2:
			ParatyphiC_02_1073.sc_con.tre
	Archeological dating of Ragna to 1200 :
		subsample 1:
			ParatyphiC_01_1200.sc_con.tre
		subsample 2:
			ParatyphiC_02_1200.sc_con.tre
		subsample 3:
			ParatyphiC_03_1200.sc_con.tre
		subsample 4:
			ParatyphiC_04_1200.sc_con.tre
		subsample 5:
			ParatyphiC_05_1200.sc_con.tre
		subsample 6:
			ParatyphiC_06_1200.sc_con.tre
		subsample 7:
			ParatyphiC_07_1200.sc_con.tre
		subsample 8:
			ParatyphiC_08_1200.sc_con.tre
		subsample 9:
			ParatyphiC_09_1200.sc_con.tre
		subsample 10:
			ParatyphiC_10_1200.sc_con.tre

All genomes in the Para C Lineage (relaxed lognormal clock rate) :
	ASM dating of Ragna to 1073 :
		subsample 1:
			ParaC_no_Lomita_01_1073.ucld_con.tre
		subsample 2:
			ParaC_no_Lomita_02_1073.ucld_con.tre
	Archeological dating of Ragna to 1200 :
		subsample 1:
			ParaC_no_Lomita_01_1200.ucld_con.tre
		subsample 2:
			ParaC_no_Lomita_02_1200.ucld_con.tre
		subsample 3:
			ParaC_no_Lomita_03_1200.ucld_con.tre
		subsample 4:
			ParaC_no_Lomita_04_1200.ucld_con.tre
		subsample 5:
			ParaC_no_Lomita_05_1200.ucld_con.tre
		subsample 6:
			ParaC_no_Lomita_06_1200.ucld_con.tre
		subsample 7:
			ParaC_no_Lomita_07_1200.ucld_con.tre
		subsample 8:
			ParaC_no_Lomita_08_1200.ucld_con.tre
		subsample 9:
			ParaC_no_Lomita_09_1200.ucld_con.tre
		subsample 10:
			ParaC_no_Lomita_10_1200.ucld_con.tre
