Concoct 8. Alignments and phylogenies of SCGs across the Tree of Life
AlignAllR.gfa: Alignments of all SCGs
AlignAllR.tree: Reconstructed phylogeny
